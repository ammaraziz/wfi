# HEADER
PARAM_FILE_NAME="FLU"
PARAM_FILE_AUTHOR="S. Shepard"
PARAM_FILE_VERSION="1.0"
PARAM_FILE_DATE="2015-01-29"


# custom params - Ammar 
MIN_LEN=75		# minimum read length - 75 is a good length to use. 