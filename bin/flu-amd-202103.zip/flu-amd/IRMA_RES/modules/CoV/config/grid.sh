# HEADER
PARAM_FILE_NAME="grid"
PARAM_FILE_AUTHOR="S. Shepard"
PARAM_FILE_VERSION="1.0"
PARAM_FILE_DATE="2020-04"


# DEFAULT settings but with SGE/OGE/UGE execution turned on.
GRID_ON=1		# needs "qsub" and a NFS install of IRMA
